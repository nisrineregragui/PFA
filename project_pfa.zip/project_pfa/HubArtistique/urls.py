from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('index/', views.index, name='index'),
    path('room-details/', views.room_details, name='room_details'), 
    path('rooms/', views.rooms, name='rooms'), 
    path('bookings/', views.bookings, name='bookings'), 
    path('dashboard/', views.dashboard, name='dashboard'),
    path('rooms_admin/', views.rooms_admin, name='rooms_admin'),  
    path('users/', views.users, name='users'),
    path('add-room/', views.add_room, name='add_room'),
    path('rooms/<int:room_id>/', views.room_details, name='room_details'),
    path('cart/', views.cart, name='cart'),
    path('remove-from-cart/<int:item_index>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('my-reservations/', views.my_reservations, name='my_reservations'),
    path('cancel-reservation/<int:reservation_id>/', views.cancel_reservation, name='cancel_reservation'),
   
]